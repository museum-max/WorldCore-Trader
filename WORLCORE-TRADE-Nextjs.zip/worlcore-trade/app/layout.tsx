import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'WORLCORE TRADE | Advanced Paper Trading',
  description: 'A professional crypto and stock market paper-trading simulator.',
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
