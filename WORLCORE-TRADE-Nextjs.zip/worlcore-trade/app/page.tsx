'use client';

import { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowDownRight, ArrowUpRight, Bell, BookOpen, BriefcaseBusiness, CandlestickChart, ChevronDown, CircleHelp, Clock3, Command, Compass, CreditCard, Eye, LayoutDashboard, Menu, MoreHorizontal, Search, Settings, ShieldCheck, Star, TrendingUp, Wallet, X } from 'lucide-react';

type Asset = { symbol: string; name: string; type: 'CRYPTO' | 'STOCK'; price: number; change: number; color: string };
type Holding = { symbol: string; quantity: number; average: number };
type Trade = { id: string; symbol: string; side: 'BUY' | 'SELL'; quantity: number; price: number; time: string };
const seedAssets: Asset[] = [
  { symbol: 'BTC', name: 'Bitcoin', type: 'CRYPTO', price: 67420.5, change: 2.48, color: '#f7931a' },
  { symbol: 'ETH', name: 'Ethereum', type: 'CRYPTO', price: 3521.8, change: 1.34, color: '#8b9cff' },
  { symbol: 'SOL', name: 'Solana', type: 'CRYPTO', price: 148.62, change: -1.82, color: '#a78bfa' },
  { symbol: 'XRP', name: 'XRP', type: 'CRYPTO', price: 0.624, change: 0.92, color: '#d8dce5' },
  { symbol: 'AAPL', name: 'Apple Inc.', type: 'STOCK', price: 227.48, change: 0.76, color: '#c5cad3' },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', type: 'STOCK', price: 138.85, change: 3.12, color: '#86b95b' },
  { symbol: 'MSFT', name: 'Microsoft', type: 'STOCK', price: 415.32, change: -0.38, color: '#72a9e8' },
  { symbol: 'TSLA', name: 'Tesla Inc.', type: 'STOCK', price: 248.5, change: 1.17, color: '#e66b66' },
];
const initialHoldings: Holding[] = [{ symbol: 'BTC', quantity: 0.18, average: 64200 }, { symbol: 'ETH', quantity: 2.4, average: 3310 }, { symbol: 'AAPL', quantity: 8, average: 216.5 }];
const money = (n: number) => n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: n < 1 ? 4 : 2 });

function makeSeries(base: number, seed: number) {
  return Array.from({ length: 42 }, (_, i) => base * (0.965 + (Math.sin(i * 0.57 + seed) * 0.012) + i * 0.00085 + Math.cos(i * 0.19 + seed) * 0.008));
}
function PriceChart({ asset, range }: { asset: Asset; range: string }) {
  const values = useMemo(() => makeSeries(asset.price, asset.symbol.length + asset.price % 7), [asset]);
  const min = Math.min(...values) * 0.996; const max = Math.max(...values) * 1.004;
  const points = values.map((v, i) => `${(i / (values.length - 1)) * 720},${190 - ((v - min) / (max - min)) * 160}`).join(' ');
  const positive = asset.change >= 0;
  return <div className="chart-wrap"><div className="chart-top"><div><div className="eyebrow">PRICE PERFORMANCE · {range}</div><div className="chart-price">{money(asset.price)} <span className={positive ? 'positive' : 'negative'}>{positive ? '+' : ''}{asset.change.toFixed(2)}%</span></div></div><div className="chart-legend"><span className="legend-dot"/> Simulated price</div></div><svg className="price-chart" viewBox="0 0 720 210" preserveAspectRatio="none" role="img" aria-label={`${asset.symbol} sample price chart`}><defs><linearGradient id="goldFade" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#d9b66d" stopOpacity=".23"/><stop offset="100%" stopColor="#d9b66d" stopOpacity="0"/></linearGradient></defs>{[30,70,110,150,190].map(y => <line key={y} x1="0" x2="720" y1={y} y2={y} stroke="#24262b" strokeDasharray="4 6"/>)}<polygon points={`0,210 ${points} 720,210`} fill="url(#goldFade)"/><polyline points={points} fill="none" stroke="#d9b66d" strokeWidth="2.4" vectorEffect="non-scaling-stroke"/><circle cx="720" cy={190 - ((values[values.length - 1] - min) / (max - min)) * 160} r="4" fill="#f0cf83"/></svg><div className="chart-axis"><span>09:00</span><span>11:00</span><span>13:00</span><span>15:00</span><span>17:00</span></div></div>;
}

export default function Home() {
  const [assets, setAssets] = useState(seedAssets);
  const [selected, setSelected] = useState('BTC');
  const [tab, setTab] = useState<'ALL' | 'CRYPTO' | 'STOCK'>('ALL');
  const [section, setSection] = useState('Overview');
  const [range, setRange] = useState('1D');
  const [cash, setCash] = useState(100000);
  const [holdings, setHoldings] = useState<Holding[]>(initialHoldings);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [quantity, setQuantity] = useState('0.01');
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [watchlist, setWatchlist] = useState(['BTC', 'ETH', 'NVDA', 'AAPL']);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const active = assets.find(a => a.symbol === selected) ?? assets[0];
  useEffect(() => {
    try {
      const saved = localStorage.getItem('worlcore-paper-v1');
      if (saved) { const p = JSON.parse(saved); if (typeof p.cash === 'number') setCash(p.cash); if (Array.isArray(p.holdings)) setHoldings(p.holdings); if (Array.isArray(p.trades)) setTrades(p.trades); if (Array.isArray(p.watchlist)) setWatchlist(p.watchlist); }
    } catch { /* ignore invalid local demo data */ }
    setHydrated(true);
  }, []);
  useEffect(() => { if (hydrated) localStorage.setItem('worlcore-paper-v1', JSON.stringify({ cash, holdings, trades, watchlist })); }, [cash, holdings, trades, watchlist, hydrated]);
  useEffect(() => { const timer = setInterval(() => setAssets(old => old.map(a => ({ ...a, price: Math.max(0.0001, a.price * (1 + (Math.random() - .5) * .0018)) }))), 4500); return () => clearInterval(timer); }, []);
  const filtered = assets.filter(a => (tab === 'ALL' || a.type === tab) && `${a.symbol} ${a.name}`.toLowerCase().includes(query.toLowerCase()));
  const holdingsValue = holdings.reduce((sum, h) => sum + h.quantity * (assets.find(a => a.symbol === h.symbol)?.price ?? h.average), 0);
  const invested = holdings.reduce((sum, h) => sum + h.quantity * h.average, 0);
  const equity = cash + holdingsValue;
  const pnl = holdingsValue - invested;
  const selectedHolding = holdings.find(h => h.symbol === active.symbol);
  const orderValue = Number(quantity) * active.price;
  const execute = () => {
    const qty = Number(quantity);
    if (!Number.isFinite(qty) || qty <= 0) { setNotice('Enter a quantity greater than zero.'); return; }
    const current = holdings.find(h => h.symbol === active.symbol);
    if (side === 'BUY') {
      if (orderValue > cash) { setNotice('Not enough virtual cash for this simulated order.'); return; }
      const oldQty = current?.quantity ?? 0; const newQty = oldQty + qty;
      setHoldings(old => current ? old.map(h => h.symbol === active.symbol ? { ...h, quantity: newQty, average: ((h.quantity * h.average) + orderValue) / newQty } : h) : [...old, { symbol: active.symbol, quantity: qty, average: active.price }]);
      setCash(v => v - orderValue);
    } else {
      if (!current || qty > current.quantity) { setNotice('You do not have enough units in this virtual portfolio.'); return; }
      setHoldings(old => old.map(h => h.symbol === active.symbol ? { ...h, quantity: h.quantity - qty } : h).filter(h => h.quantity > 0.00000001));
      setCash(v => v + orderValue);
    }
    setTrades(old => [{ id: crypto.randomUUID(), symbol: active.symbol, side, quantity: qty, price: active.price, time: new Date().toLocaleString() }, ...old].slice(0, 100));
    setNotice(`${side} order simulated successfully. No real asset was purchased or sold.`);
  };
  const reset = () => { setCash(100000); setHoldings([]); setTrades([]); setNotice('Paper account reset to $100,000 virtual cash.'); };
  const toggleWatch = (symbol: string) => setWatchlist(old => old.includes(symbol) ? old.filter(s => s !== symbol) : [...old, symbol]);
  const nav = [{ name: 'Overview', icon: LayoutDashboard }, { name: 'Markets', icon: Compass }, { name: 'Trade Simulator', icon: CandlestickChart }, { name: 'Portfolio', icon: BriefcaseBusiness }, { name: 'Watchlist', icon: Star }, { name: 'Activity', icon: Clock3 }];
  return <main className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}><div className="brand"><div className="brand-mark">W</div><div><b>WORLCORE</b><span>TRADE TERMINAL</span></div><button className="mobile-close" onClick={() => setMobileOpen(false)}><X size={18}/></button></div><div className="workspace"><span className="workspace-icon"><Activity size={15}/></span><div><b>Personal Workspace</b><small>Paper account</small></div><ChevronDown size={14}/></div><div className="nav-label">WORKSPACE</div><nav>{nav.map(item => <button key={item.name} className={`nav-item ${section === item.name ? 'active' : ''}`} onClick={() => { setSection(item.name); setMobileOpen(false); }}><item.icon size={17}/><span>{item.name}</span>{item.name === 'Activity' && <span className="nav-count">{trades.length}</span>}</button>)}</nav><div className="nav-label tools-label">TOOLS</div><nav><button className="nav-item" onClick={() => setNotice('Research tools are educational placeholders in this starter build.')}><BookOpen size={17}/><span>Research & Learn</span></button><button className="nav-item" onClick={() => setNotice('Settings panel is planned for a future version.')}><Settings size={17}/><span>Settings</span></button></nav><div className="sidebar-bottom"><div className="security-card"><ShieldCheck size={18}/><b>Simulation mode</b><p>All balances and orders are virtual. No broker is connected.</p></div><div className="profile"><div className="avatar">WT</div><div><b>WORLCORE User</b><small>Demo account</small></div><MoreHorizontal size={18}/></div></div></aside>
    <section className="main-area"><header className="topbar"><button className="menu-button" onClick={() => setMobileOpen(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{section}</b></div><div className="top-actions"><div className="market-status"><span/> DEMO MARKET</div><button className="icon-button" aria-label="Notifications" onClick={() => setNotice('You are all caught up.') }><Bell size={18}/></button><div className="top-avatar">WT</div></div></header>
    <div className="content"><div className="welcome-row"><div><div className="eyebrow">THURSDAY, NOVEMBER 05, 2026 <span className="live-dot"/></div><h1>{section === 'Overview' ? 'Market overview' : section}</h1><p className="subheading">Your professional trading workspace, powered by virtual capital.</p></div><div className="header-buttons"><button className="secondary-button" onClick={reset}><span>↺</span> Reset demo</button><button className="gold-button" onClick={() => { setSection('Trade Simulator'); document.getElementById('order-ticket')?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }}> <CandlestickChart size={16}/> Open simulator</button></div></div>
    <div className="demo-banner"><div className="demo-icon"><ShieldCheck size={18}/></div><div><b>Paper trading environment</b><span>Prices are illustrative and simulated. This app does not connect to exchanges or execute real trades.</span></div><span className="demo-tag">VIRTUAL FUNDS</span></div>
    <div className="stats-grid"><div className="stat-card"><div className="stat-head">TOTAL ACCOUNT VALUE <Wallet size={16}/></div><div className="stat-value">{money(equity)}</div><div className="stat-foot"><span className="gold-text">●</span> Virtual cash + holdings</div></div><div className="stat-card"><div className="stat-head">AVAILABLE CASH <CreditCard size={16}/></div><div className="stat-value">{money(cash)}</div><div className="stat-foot">Ready for simulated orders</div></div><div className="stat-card"><div className="stat-head">OPEN POSITIONS <BriefcaseBusiness size={16}/></div><div className="stat-value">{holdings.length.toString().padStart(2, '0')}</div><div className="stat-foot">Assets in your portfolio</div></div><div className="stat-card"><div className="stat-head">UNREALIZED P/L <TrendingUp size={16}/></div><div className={`stat-value ${pnl >= 0 ? 'positive' : 'negative'}`}>{pnl >= 0 ? '+' : ''}{money(pnl)}</div><div className="stat-foot">Based on sample entry prices</div></div></div>
    <div className="dashboard-grid"><div className="panel chart-panel"><div className="panel-heading"><div><div className="eyebrow">MARKET CHART</div><h2>{active.name} <span className="symbol-pill">{active.symbol}</span></h2></div><div className="range-tabs">{['1H','1D','1W','1M','1Y'].map(r => <button key={r} className={range === r ? 'selected' : ''} onClick={() => setRange(r)}>{r}</button>)}</div></div><PriceChart asset={active} range={range}/><div className="chart-footer"><span><i className="legend-dot"/> Sample price series</span><span>Illustrative chart · Not exchange data</span></div></div>
    <div className="panel order-panel" id="order-ticket"><div className="panel-heading"><div><div className="eyebrow">ORDER TICKET</div><h2>Place an order</h2></div><span className="ticket-icon"><Command size={17}/></span></div><div className="order-toggle"><button className={side === 'BUY' ? 'buy-active' : ''} onClick={() => setSide('BUY')}>Buy</button><button className={side === 'SELL' ? 'sell-active' : ''} onClick={() => setSide('SELL')}>Sell</button></div><label className="field-label">ASSET</label><div className="asset-select"><span className="asset-mini" style={{ background: active.color }}>{active.symbol.slice(0,1)}</span><div><b>{active.symbol}</b><small>{active.name}</small></div><span className="select-price">{money(active.price)}</span></div><label className="field-label" htmlFor="quantity">QUANTITY</label><div className="quantity-field"><input id="quantity" type="number" min="0" step="any" value={quantity} onChange={e => setQuantity(e.target.value)}/><span>{active.symbol}</span></div><div className="order-detail"><span>Estimated order value</span><b>{money(orderValue || 0)}</b></div><div className="order-detail"><span>Available virtual cash</span><b>{money(cash)}</b></div><button className={`submit-order ${side === 'SELL' ? 'submit-sell' : ''}`} onClick={execute}>{side === 'BUY' ? 'Simulate buy order' : 'Simulate sell order'} <ArrowUpRight size={16}/></button><p className="order-note"><ShieldCheck size={13}/> Simulated instantly · No real funds</p></div>
    <div className="panel markets-panel"><div className="panel-heading"><div><div className="eyebrow">DISCOVER</div><h2>Markets</h2></div><button className="text-action" onClick={() => setSection('Markets')}>View all <ArrowUpRight size={14}/></button></div><div className="market-tools"><div className="search-box"><Search size={15}/><input placeholder="Search assets..." value={query} onChange={e => setQuery(e.target.value)}/></div><div className="filter-tabs">{['ALL','CRYPTO','STOCK'].map(t => <button key={t} className={tab === t ? 'chosen' : ''} onClick={() => setTab(t as typeof tab)}>{t}</button>)}</div></div><div className="market-table"><div className="table-head"><span>ASSET</span><span>PRICE</span><span>24H</span><span></span></div>{filtered.map(a => <div key={a.symbol} className={`market-row ${selected === a.symbol ? 'row-selected' : ''}`} onClick={() => setSelected(a.symbol)}><div className="asset-name"><span className="asset-icon" style={{ background: a.color }}>{a.symbol.slice(0,1)}</span><div><b>{a.symbol}</b><small>{a.name}</small></div></div><b className="price-cell">{money(a.price)}</b><span className={a.change >= 0 ? 'positive' : 'negative'}>{a.change >= 0 ? '+' : ''}{a.change.toFixed(2)}%</span><button className={`star-button ${watchlist.includes(a.symbol) ? 'starred' : ''}`} onClick={e => { e.stopPropagation(); toggleWatch(a.symbol); }} aria-label={`Toggle ${a.symbol} watchlist`}><Star size={15} fill={watchlist.includes(a.symbol) ? 'currentColor' : 'none'}/></button></div>)}</div></div>
    <div className="panel portfolio-panel"><div className="panel-heading"><div><div className="eyebrow">YOUR ASSETS</div><h2>Portfolio positions</h2></div><button className="text-action" onClick={() => setSection('Portfolio')}>Details <ArrowUpRight size={14}/></button></div>{holdings.length === 0 ? <div className="empty-state"><BriefcaseBusiness size={24}/><b>No open positions</b><span>Place a simulated buy order to add an asset.</span></div> : <div className="positions-table"><div className="table-head"><span>ASSET</span><span>QUANTITY</span><span>MARKET VALUE</span><span>UNREALIZED P/L</span></div>{holdings.map(h => { const a = assets.find(x => x.symbol === h.symbol)!; const value = h.quantity * a.price; const change = value - h.quantity * h.average; return <div className="position-row" key={h.symbol}><div className="asset-name"><span className="asset-icon" style={{ background: a.color }}>{a.symbol.slice(0,1)}</span><div><b>{h.symbol}</b><small>{a.name}</small></div></div><span>{h.quantity.toLocaleString('en-US', { maximumFractionDigits: 6 })}</span><b>{money(value)}</b><span className={change >= 0 ? 'positive' : 'negative'}>{change >= 0 ? '+' : ''}{money(change)}</span></div>; })}</div>}</div>
    <div className="panel activity-panel"><div className="panel-heading"><div><div className="eyebrow">RECENT ORDERS</div><h2>Trading activity</h2></div><span className="activity-count">{trades.length} orders</span></div>{trades.length === 0 ? <div className="empty-state compact"><Clock3 size={22}/><span>Your simulated orders will appear here.</span></div> : <div className="activity-list">{trades.slice(0, 5).map(t => <div className="activity-row" key={t.id}><span className={`trade-type ${t.side.toLowerCase()}`}>{t.side === 'BUY' ? <ArrowDownRight size={15}/> : <ArrowUpRight size={15}/>}</span><div className="activity-desc"><b>{t.side} {t.symbol}</b><small>{t.quantity} units · {t.time}</small></div><div className="activity-amount"><b>{money(t.quantity * t.price)}</b><small>{money(t.price)} / unit</small></div></div>)}</div>}</div>
    </div><footer className="footer"><span>© 2026 WORLCORE TRADE</span><span><CircleHelp size={13}/> Educational paper-trading simulator · Sample data only</span></footer></div></section>
    {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={() => setNotice('')}><X size={15}/></button></div>}
  </main>;
}
