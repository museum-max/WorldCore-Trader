# WORLCORE TRADE

A premium black-and-gold Next.js paper-trading simulator for learning with virtual capital. This starter app has no broker, exchange, payment, deposit, withdrawal, or real-order integration.

## Features
- Crypto and stock sample asset universe
- Simulated changing prices (browser-only demo movement)
- Buy/sell paper orders with cash and position validation
- Portfolio value and unrealized P/L calculations
- Watchlist, asset search, and market filters
- Recent simulated order history
- Local browser persistence via `localStorage`
- Responsive layout for desktop and mobile

## Requirements
- Node.js 20.9+ (Node 22 LTS recommended)
- npm

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm start
```

## Deploy to Vercel
1. Create a GitHub repository named `worlcore-trade`.
2. Upload the contents of this folder (upload the files inside it, not the ZIP file itself).
3. Visit https://vercel.com/new and import the GitHub repository.
4. Keep the detected framework as **Next.js**. No environment variables are required for this demo.
5. Click **Deploy**. Vercel detects `npm run build` automatically.

## Important notes before public use
- The displayed asset prices and chart are illustrative sample values, not live market data.
- Price changes are generated in the browser for demonstration only.
- Paper-account state is stored in the current browser's localStorage; it is not a secure account system and does not sync across devices.
- There is no authentication, server-side database, order execution, financial advice, or real-money functionality.
- Do not add real deposits, withdrawals, brokerage connections, or live order execution without appropriate legal, security, compliance, and adult professional review.

## Project structure

```text
worlcore-trade/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── .gitignore
├── next-env.d.ts
├── next.config.ts
├── package.json
├── README.md
└── tsconfig.json
```
